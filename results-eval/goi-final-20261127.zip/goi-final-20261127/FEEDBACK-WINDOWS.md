# Feedback chạy trên Windows (27/11/2026)

Máy: Windows 11, Python 3.12, Docker Desktop (WSL2), PowerShell / Git Bash. Clone sạch `main` tại commit `a14c782` và làm theo README.

## Đã chạy thật trên code mới

| # | Bước README | Lỗi | Cách sửa đề xuất |
|---|---|---|---|
| 1 | 1. `pip install -r config/requirements/host.txt` | **Fail.** `uvloop==0.23.0` báo `uvloop does not support Windows`. | `config/requirements/ai.txt`: `uvloop==0.23.0 ; sys_platform != "win32"`. Sửa xong cài được, import OK. |
| 2 | 2. `python scripts/compose_up.py` | Nhận GPU đúng (RTX 3050) và build xong ai/backend/speech, nhưng Docker daemon sập khi giải nén image `speech-gpu` (`rpc error: code = Unavailable ... EOF`). Nguyên nhân: ổ C chỉ còn 9,2 GB. | Do máy thiếu ổ, không phải lỗi code. Nên kiểm tra dung lượng trống trước khi build, và nói rõ image GPU cần bao nhiêu GB. |
| 3 | 5. ASR local | Lệnh dùng `./dataset/audio`, nhưng repo không có thư mục này. | Ghi rõ lấy audio ở đâu (gói `audio-vieneu-120-cuoc.zip`) và giải nén vào đâu. |
| 4 | Docker | Tên image cố định `telesale-btc-*:local`. Đổi `COMPOSE_PROJECT_NAME` thì volume tách ra, nhưng image vẫn ghi đè lên image của bản cũ. Project name `telesale-btc` cũng cố định trong `docker-compose.yml` và `.env.example`, nên bản mới dùng lại volume DB của bản cũ. | Đặt tên image theo project, hoặc ghi chú trong README. |

## Lỗi gặp khi chạy bản trước, bản mới vẫn còn (rà code)

Các lỗi dưới đây tôi đã gặp và sửa trên bản trước để chạy hết eval 48 kịch bản. Code mới vẫn còn nguyên nhưng chưa chạy tới bước đó vì lỗi #2 ở trên.

| # | Chỗ | Lỗi trên Windows | Cách đã sửa |
|---|---|---|---|
| 5 | `.gitattributes` | Chỉ có `*.sh`. Git trên Windows (`core.autocrlf=true`) chuyển JSON sang CRLF, nên eval dừng với `scenario_manifest_hash_mismatch:TEAM-01.json`. | Thêm `*.json text eol=lf` và `*.jsonl text eol=lf`. |
| 6 | `seed_btc.py` / psycopg async | Windows mặc định dùng ProactorEventLoop, psycopg async báo `InterfaceError`. | Đặt `asyncio.WindowsSelectorEventLoopPolicy()` trong `ai-services/app/__init__.py` và `scripts/btc_host.py` khi `sys.platform == 'win32'`. |
| 7 | `ai-services/eval_harness/run_official.py` | `os.sysconf` không có trên Windows (lấy RAM cho metadata). | Thêm hàm `_ram_bytes()` dùng `GlobalMemoryStatusEx` khi không có `sysconf`. |
| 8 | `ai-services/eval_harness/benchmark_runner.py` (`run_configuration`) | Gọi `write_jsonl(trace, out)` (ghi tạm rồi `os.replace`) khi `out` vẫn đang mở, nên Windows báo `PermissionError [WinError 5]`. | `stream.close()` trước `write_jsonl`. |
| 9 | `ai-services/eval_harness/knowledge_triplet.py` | `import fcntl` không có trên Windows, nên bước knowledge sau eval bị `ModuleNotFoundError`. | Hàm khóa file dùng `msvcrt.locking` trên Windows, `fcntl.flock` trên Linux/macOS. |
| 10 | `config/requirements/asr.txt` | `av==19.0.2` làm faster-whisper lỗi `av.open(metadata_errors=...)`. | `av==18.1.1` (18.1.0 đã bị yank). |
| 11 | Đọc/ghi file | Khoảng 78 chỗ `open()`/`read_text()` không ghi `encoding`, nên Windows dùng cp1252 và báo `UnicodeDecodeError`. | Tạm thời chạy với `PYTHONUTF8=1` (`$env:PYTHONUTF8=1` trong PowerShell). Nên ghi vào README hoặc thêm `encoding='utf-8'`. |
| 12 | `.env` | Mật khẩu MCP phải là chuỗi hex (`mcp_roles.py`). Sinh mật khẩu ngẫu nhiên kiểu khác thì seed báo `MCP database passwords must be nonempty hex strings`. Đổi secret xong cần `docker compose up -d --force-recreate`. | Ghi chú trong `.env.example`. |

## Lỗi harness (không riêng Windows)

| # | Lỗi | Trạng thái |
|---|---|---|
| 13 | Guardrail `_money_evidenced` (`checks.py`) không coi `order.create` thành công là bằng chứng giá. Agent nhắc lại "đã lên đơn ... giá 990.000đ" thì bị chặn `price_without_quote` (TEAM-31). | Đã sửa trên bản cũ: chấp nhận số tiền khớp `total_vnd` của `order.create` có `status=created`. Thêm 2 test. Chưa kiểm tra trên code mới. |
| 14 | Một lượt không có câu trả lời (`reply_error`) làm dừng cả run 48 kịch bản. Nếu gặp trên bộ ẩn của BTC thì mất cả trace. | Chưa sửa. Không tái hiện được vì phụ thuộc output model. |
| 15 | Khoảng 48 test guardrail (`ai-services/test`) đang fail trên code trước khi tôi sửa, lệch với code hiện tại. | Chưa sửa. |
| 16 | Eval 48 kịch bản: 100/323 lượt Full bị guardrail từ chối bản nháp đầu, làm TTFT p95 = 6,5 s (> 3 s). 1 lượt `GraphRecursionError`, nên execution degraded và bước Knowledge bị bỏ qua. | Cần xem lại. |
