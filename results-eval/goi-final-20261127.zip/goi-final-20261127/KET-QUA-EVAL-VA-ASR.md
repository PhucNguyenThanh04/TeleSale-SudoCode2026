# Kết quả eval hội thoại và chấm diarization (27/11/2026)

Chạy trên máy Windows 11 (16 luồng CPU, 15,6 GB RAM, GPU RTX 3050 Laptop 4 GB), model `gemma4:31b` qua Ollama Cloud, gói BTC bản cập nhật v2 (`reference_eval.py` và `asr/ground_truth.json` mới, 28/28 hash khớp manifest).

## Đã làm

1. Chạy eval đầy đủ Full và Baseline không memory trên 48 kịch bản `eval/scenario_final` (run `20261127T065208Z-d1f480a3`).
2. Sửa guardrail chặn nhầm câu nhắc lại giá sau khi `order.create` thành công (lỗi làm run trước dừng ở TEAM-31). Thêm 2 test, không làm fail thêm test nào.
3. Sửa 7 chỗ không chạy được trên Windows để eval chạy hết (xem `FEEDBACK-WINDOWS.md`).
4. Chấm lại diarization theo `segments.json` trên kết quả ASR của nhóm (`team-all-vieneu-baseline-v3`, `btc-vieneu-baseline-v1`). WER/CER/Entity chấm lại khớp đúng số của nhóm.

## Eval hội thoại (48 kịch bản, 118 cuộc, 323 lượt mỗi cấu hình)

| Chỉ số | Full | Baseline | Chênh lệch | Ngưỡng M1 |
|---|---:|---:|---:|---|
| RQR ↓ | 4,5% (3/67) | 21,6% (22/102) | giảm 79,2% | giảm ≥40%: ĐẠT |
| CCR ↑ | 49,0% (47/96) | 13,5% (13/96) | +35,5 đpt | — |
| TSR ↑ | 77,1% (37/48) | 64,6% (31/48) | +12,5 đpt | ≥70%: ĐẠT |
| TSR ca khó ↑ | 73,7% | 57,9% | +15,8 đpt | — |
| HR ↓ | 2,1% (2/96) | 1,3% (1/76) | +0,8 đpt | — |
| HR giá/KM ↓ | 2,8% (2/71) | 1,7% (1/58) | +1,1 đpt | ≤5%: ĐẠT |
| Vi phạm guardrail | 0 | 0 | 0 | ĐẠT |
| Số lượt TB/cuộc | 2,74 | 2,74 | 0 | — |
| Calls-to-close | 1,97 | 1,89 | +0,08 | — |
| TTFT p50 / p95 (ms) | 2600 / 6454 | 2697 / 5669 | — | p95 ≤3000: CHƯA ĐẠT |
| Total p50 / p95 (ms) | 2713 / 6454 | 2697 / 5669 | — | p95 ≤8000: ĐẠT |
| Call Brief p50 / p95 (ms) | 176 / 259 | — | — | ≤5000: ĐẠT (đo 69/70) |

Nghiệm thu hội thoại M1 theo harness: **CHƯA ĐẠT**, do:

- **TTFT p95 6,5 s > 3 s.** Có 100/323 lượt ở Full (101 ở Baseline) bị guardrail từ chối bản nháp đầu và phải gọi model sửa lại; đây có vẻ là nguyên nhân chính làm p95 cao.
- **Execution health = degraded.** 1 lượt Full lỗi `GraphRecursionError`; vài lượt `unknown_sku` ở `pricing.get_quote`/`inventory.check`. Vì cặp không "healthy" nên bước Knowledge (K0 → K1) bị bỏ qua.
- **Extraction review** còn ứng viên chưa phân giải, cần người rà.
- **Call Brief** thiếu 1 lần đo (69/70) nên chưa có giá trị max.

Ca HR được lưu: Full TEAM-42 call_2 (lượt 1 và 3, `price_vnd`, chưa đủ bằng chứng để phân loại); Baseline TEAM-26 call_2 lượt 3 (báo giá đúng SKU-SN-RUN1-42-XAM nhưng kịch bản kỳ vọng SKU-SN-RUN2-42-XAM).

## Diarization (độ đúng vai người nói theo lượt)

| Bộ | Số cuộc | B0 | B1 | B2 |
|---|---:|---:|---:|---:|
| Khách mới T30–T46 | 68 | 76,5 | 76,5 | 78,3 |
| Phiên 1 synthetic | 11 | 93,5 | 93,5 | 94,4 |
| Phiên 1 clone | 11 | 96,3 | 96,3 | 96,3 |
| Phiên 2 | 22 | 83,0 | 83,0 | 83,3 |
| Phiên 3 | 8 | 85,9 | 85,9 | 87,5 |
| **Toàn bộ 120 file (1.089 đoạn)** | 120 | **82,3** | **82,3** | **83,5** |
| Dữ liệu BTC D01–D04 | 4 | 97,1 | 97,1 | 97,1 |

WER/CER/Entity B2 chấm lại khớp số của nhóm: bộ nhóm 8,4 / 5,2 / 78,1; BTC 10,7 / 5,8 / 75,9. Chi tiết từng bộ trong `score.json` của gói `ket-qua-diarization.zip`.

Bộ khách mới có diarization thấp nhất (76–78%), kéo trung bình toàn bộ xuống.

## Chưa làm

- **Chạy lại ASR whisper-turbo B0/B1/B2 để kiểm tra tái lập: chưa xong.** Máy này chạy ~1x thời gian thực mỗi lượt (máy nhóm RTF 0,33), cần ~4–4,5 giờ cho 120 + 4 file. Các lần chạy dở (`*-rerun*-20261127`) không có `score.json` nên không đưa vào gói.
- Chưa chạy ASR theo README với `whisper-small` (`python -m speech transcribe` / `speech eval`).
- Chưa chạy vòng Knowledge K0 → K1 (bị bỏ qua vì execution degraded).
- Chưa chạy được code mới của anh Phúc tới bước seed/eval: `compose_up.py` dừng khi build image `speech-gpu` vì ổ C còn 9,2 GB (README yêu cầu 20 GB trống), Docker daemon bị sập.

## File trong gói

- `ket-qua-eval-48-kich-ban.zip`: toàn bộ thư mục run `20261127T065208Z-d1f480a3` (`run.json`, `btc_score.json`, `m1_conversation_acceptance.json`, trace, diagnostics, extraction). Đã kiểm tra không chứa key/token trong `.env`.
- `ket-qua-diarization.zip`: điểm diarization + WER/CER/Entity theo từng bộ và cấu hình B0/B1/B2.
- `FEEDBACK-WINDOWS.md`: lỗi khi chạy trên Windows, gửi anh Phúc.
